package com.meulauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class PinService : AccessibilityService() {
    private var last = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e == null || e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (!getSharedPreferences("launcher", MODE_PRIVATE).getBoolean("pin", false)) return
        if (pkg.startsWith("com.amazon") && pkg.contains("launcher")) {
            val now = System.currentTimeMillis()
            if (now - last < 1500) return
            last = now
            try {
                startActivity(
                    Intent(this, MainActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                )
            } catch (x: Exception) {
            }
        }
    }

    override fun onInterrupt() {}
}
