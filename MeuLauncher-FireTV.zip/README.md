# Meu Launcher (Fire TV)

Launcher para Fire TV: cartazes de filmes no topo, apps logo abaixo e menu de configurações.

## Gerar o APK
1. Crie um repositório no GitHub e envie todos os arquivos desta pasta.
2. Abra a aba **Actions**, rode **Gerar APK** (ou faça um push).
3. Baixe o artefato **MeuLauncher-apk** (arquivo app-debug.apk).

## Instalar no Fire TV
Ative **Apps de fontes desconhecidas** e instale o APK com o app Downloader.

## Cartazes reais
Em Configurações, cole uma chave gratuita da API do TMDB (themoviedb.org). Sem a chave, aparece a lista de lançamentos embutida.

## Cartazes reais (chave TMDB no build)
Crie uma chave gratuita em themoviedb.org (Configurações → API). No GitHub: Settings → Secrets and variables → Actions → New repository secret, nome `TMDB_KEY`. O workflow grava a chave no APK.

## Fixar launcher
Em Configurações → "Fixar launcher": ative o serviço Meu Launcher em Acessibilidade (ou conceda WRITE_SECURE_SETTINGS por ADB). Quando a tela inicial original abrir, o app volta ao Meu Launcher.
